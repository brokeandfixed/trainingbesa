using Moq;
using PT.TrainningBesa04.Controllers;
using PT.TrainningBesa04.Services;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using System;
using PT.TrainningBesa04.Models.Dtos;
using Xunit;

namespace PT.TrainningBesa04.Tests
{    
    public class ContactsControllerTest
    {
        private Mock<IContactsService> _mockIContactsService;
        private ContactsController _contactsController;
        void InitData()
        {
            _mockIContactsService = new Mock<IContactsService>();
            _contactsController = new ContactsController(_mockIContactsService.Object);
        }

        [Fact]
        public void GetByIdContacts_Ok()
        {
            // Arrange
            InitData();
            _mockIContactsService.Setup(_ => _.GetById(It.IsAny<Guid>())).Returns(new ContactDto());

            // Act
            var result = _contactsController.GetById(Guid.NewGuid().ToString());

            // Assert
            _mockIContactsService.Verify(_ => _.GetById(It.IsAny<Guid>()), Times.Once);
            result.Should().NotBeNull().And.BeOfType<OkObjectResult>();            
        }

        //[Fact]
        //public void GetAllContacts_Ok()
        //{
        //    InitData();
        //    _mockIContactsService.Setup(_ => _.GetById(It.IsAny<Guid>())).Returns(new ContactDto());

        //    var result = _contactsController.GetAll();
        //    _mockIContactsService.Verify(_ => _)
        //}
    }
}
